public class Survey {
}
