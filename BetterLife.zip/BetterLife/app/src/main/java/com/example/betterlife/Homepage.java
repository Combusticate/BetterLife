package com.example.betterlife;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.facebook.CallbackManager;
import com.facebook.login.LoginManager;

public class Homepage extends AppCompatActivity {

    Button logout;

    CallbackManager callbackManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homepage);

        SharedPreferences prefs = getApplicationContext().getSharedPreferences("Prefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = getApplicationContext().getSharedPreferences("Prefs", MODE_PRIVATE).edit();

        callbackManager = CallbackManager.Factory.create();

        logout = findViewById(R.id.Logout);

        boolean isLoggedIn = getIntent().getBooleanExtra("isLoggedIn", false);

        if (!isLoggedIn) {
            startActivity(new Intent(Homepage.this, start.class));
            finish();
        }

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //LoginManager.getInstance().logOut();
                editor.putBoolean("isLoggedIn", false);
                editor.apply();
                startActivity(new Intent(Homepage.this, start.class));
                finish();
            }
        });
    }

    @Override
    public void onBackPressed() {
        Toast.makeText(this, "Back button is disabled", Toast.LENGTH_SHORT).show();
    }

}