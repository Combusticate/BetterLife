package com.example.betterlife;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONException;
import org.json.JSONObject;


import com.example.betterlife.QuestionsAnswers;

import org.json.JSONObject;


public class Survey extends AppCompatActivity implements View.OnClickListener {

    TextView totalQuestionsTextView;
    TextView questionTextView;
    TextView questionNum;

    Button ans, ansB,ansC,ansD;
    Button submitBtn;
    LinearLayout choicesL;
    int totalQuestion = QuestionsAnswers.questions.length;
    String selectedAnswer = "";
    String selectedBtn = "";
    int currentIn = 0;
    int questionNumber = 1;
    int totalAnswers = QuestionsAnswers.choices.length;
    int sizeQ = 7 ;
    QuestionsAnswers myObject = new QuestionsAnswers(sizeQ);



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_survey);
        totalQuestionsTextView = findViewById(R.id.total_question);
        questionNum = findViewById(R.id.num_question);

        questionTextView = findViewById(R.id.question);

        choicesL = findViewById(R.id.choices_layout);
        submitBtn = findViewById(R.id.submit_btn);
        questionTextView.setVisibility(View.GONE);
        choicesL.setVisibility(View.GONE); // Hide the button
        submitBtn.setVisibility(View.GONE); // Hide the button

       /*
        ansB = findViewById(R.id.ans_B);
        ansC = findViewById(R.id.ans_C);
        ansD = findViewById(R.id.ans_D);*/



        /*ansB.setOnClickListener(this);
        ansC.setOnClickListener(this);
        ansD.setOnClickListener(this);*/
        submitBtn.setOnClickListener(this);
        totalQuestionsTextView.setText("Total questions : " + totalQuestion);
        questionNum.setText("Question Number : " + questionNumber);


           String question = QuestionsAnswers.questions[currentIn];
            choicesL.setVisibility(View.VISIBLE);
            if (question != null ) {
                // show the question
                questionTextView.setVisibility(View.VISIBLE);
                submitBtn.setVisibility(View.VISIBLE);

            } else {

            }

        for (int ansIndex = 0 ; ansIndex < QuestionsAnswers.choices[currentIn].length; ansIndex++){
            String answer = QuestionsAnswers.choices[currentIn][ansIndex];
            Button button = new Button(this);
            button.setLayoutParams(new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT));
            button.setText(answer);
            button.setBackgroundColor(Color.WHITE);
            button.setId(currentIn);

            choicesL.addView(button);
             // Get the existing layout parameters of the button
            LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) button.getLayoutParams();
            // Set the desired margin, padding value
            int marginEnd = 16; // in pixels
            int padding = 16;
            int margin = 5;
            // Convert the margin value from pixels to dp
            float marginDp = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, margin, getResources().getDisplayMetrics());
            // Update the marginEnd property
            layoutParams.setMarginEnd(marginEnd);
            button.setPadding(padding, padding, padding, padding);  // Apply the padding to all sides of the button
            layoutParams.setMargins((int) marginDp, (int) marginDp, (int) marginDp, (int) marginDp); //Set the margin on all sides of the button
            // Apply the updated layout parameters to the button
            button.setLayoutParams(layoutParams);
            // the first time the user click the answers of the first question
            button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(getApplicationContext(), "Button Clicked", Toast.LENGTH_SHORT).show();
                    selectedBtn = button.getText().toString();
                    Log.d("TAG", "Value: " + selectedBtn);
                    Toast.makeText(getApplicationContext(), "Value: " + selectedBtn, Toast.LENGTH_SHORT).show();
                    //QuestionsAnswers.answers[currentIn][0] = selectedBtn;
                    myObject.setData(currentIn, selectedBtn);

                }
            });



        }




    }


    public JSONObject createJsonObject( String value) {
        JSONObject jsonObject = new JSONObject();

        try {
            // Add key-value pairs to the JSON object
            jsonObject.put(value, "John");
            jsonObject.put("sex", 25);
            jsonObject.put("city", "New York");

        } catch (JSONException e) {
            e.printStackTrace();
        }
        return jsonObject;
    }

    @Override
    public void onClick(View view) {
        Button clickedButton = (Button) view;

        if (clickedButton.getId()==R.id.submit_btn){
          // selectedAnswer = clickedButton.getText().toString();
           //Log.d("TAG", "Value: " + selectedAnswer);
          // Toast.makeText(getApplicationContext(), "Value: " + selectedAnswer, Toast.LENGTH_SHORT).show();
            currentIn++;
            questionNumber++;
            loadNewQuestion();
        }else{


        }

    }

    void loadNewQuestion(){
        if(currentIn == totalQuestion){
            finishQuiz();
            return;
        }
        Toast.makeText(getApplicationContext(), "INDEX: " + currentIn, Toast.LENGTH_SHORT).show();
        // Removing all buttons in the layout
        LinearLayout layout = findViewById(R.id.choices_layout);
        layout.removeAllViews();
        // setting the new question
        questionNum.setText("Question Number : " + questionNumber );
        questionTextView.setText(QuestionsAnswers.questions[currentIn]);
        // displaying the answers
        for (int ansIndex = 0 ; ansIndex < QuestionsAnswers.choices[currentIn].length; ansIndex++){
            String answer = QuestionsAnswers.choices[currentIn][ansIndex];
            Button button = new Button(this);
            button.setLayoutParams(new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT));
            button.setText(answer);
            button.setBackgroundColor(Color.WHITE);
            choicesL.addView(button);
            // Get the existing layout parameters of the button
            LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) button.getLayoutParams();
            // Set the desired margin, padding value
            int marginEnd = 16; // in pixels
            int padding = 16;
            int margin = 5;
            // Convert the margin value from pixels to dp
            float marginDp = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, margin, getResources().getDisplayMetrics());
            // Update the marginEnd property
            layoutParams.setMarginEnd(marginEnd);
            button.setPadding(padding, padding, padding, padding);  // Apply the padding to all sides of the button
            layoutParams.setMargins((int) marginDp, (int) marginDp, (int) marginDp, (int) marginDp); //Set the margin on all sides of the button
            // Apply the updated layout parameters to the button
            button.setLayoutParams(layoutParams);

            button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(getApplicationContext(), "Button Clicked", Toast.LENGTH_SHORT).show();
                    selectedBtn = button.getText().toString();
                    Log.d("TAG", "Value: " + selectedBtn);
                    Toast.makeText(getApplicationContext(), "Value: " + selectedBtn, Toast.LENGTH_SHORT).show();
                    // QuestionsAnswers.answers[currentIn][0] = selectedBtn;
                    myObject.setData(currentIn, selectedBtn);

                }
            });


        }
    }

    void finishQuiz(){
        // Removing all buttons in the layout
        LinearLayout layout = findViewById(R.id.choices_layout);
        layout.removeAllViews();
        questionTextView.setText("These are your answers");
        String arrAns[] = myObject.getData();
        for (int ansIn = 0 ; ansIn < myObject.getSize(); ansIn++){

            Button button = new Button(this);
            button.setLayoutParams(new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT));
            button.setText(arrAns[ansIn]);
            button.setBackgroundColor(Color.WHITE);
            choicesL.addView(button);
            // Get the existing layout parameters of the button
            LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) button.getLayoutParams();
            // Set the desired margin, padding value
            int marginEnd = 16; // in pixels
            int padding = 16;
            int margin = 5;
            // Convert the margin value from pixels to dp
            float marginDp = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, margin, getResources().getDisplayMetrics());
            // Update the marginEnd property
            layoutParams.setMarginEnd(marginEnd);
            button.setPadding(padding, padding, padding, padding);  // Apply the padding to all sides of the button
            layoutParams.setMargins((int) marginDp, (int) marginDp, (int) marginDp, (int) marginDp); //Set the margin on all sides of the button
            // Apply the updated layout parameters to the button
            button.setLayoutParams(layoutParams);




        }

    }
}
