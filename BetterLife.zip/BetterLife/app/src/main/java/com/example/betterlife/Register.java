package com.example.betterlife;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.example.betterlife.databinding.ActivityRegisterBinding;

public class Register extends AppCompatActivity {

    ActivityRegisterBinding binding;
    DatabaseHelper databaseHelper;
    EditText newpassword, passwordconf, newemail;
    MaterialButton regbtn, logbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityRegisterBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        SharedPreferences.Editor editor = getSharedPreferences("Prefs", MODE_PRIVATE).edit();

        databaseHelper = new DatabaseHelper(this);

        newpassword = findViewById(R.id.newpassword);
        passwordconf = findViewById(R.id.newpasswordconf);
        newemail = findViewById(R.id.newemail);
        regbtn = findViewById(R.id.regbtn);

        binding.regbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = binding.newemail.getText().toString();
                String password = binding.newpassword.getText().toString();
                String confirmPassword = binding.newpasswordconf.getText().toString();
                if(email.equals("")||password.equals("")||confirmPassword.equals(""))
                    Toast.makeText(Register.this, "All fields are mandatory", Toast.LENGTH_SHORT).show();
                else{
                    if(password.equals(confirmPassword)){
                        Boolean checkUserEmail = databaseHelper.checkEmail(email);
                        if(checkUserEmail == false){
                            Boolean insert = databaseHelper.insertData(email, password);
                            if(insert == true){
                                Toast.makeText(Register.this, "Signup Successfully!", Toast.LENGTH_SHORT).show();
                                editor.putBoolean("isLoggedIn", true);
                                editor.apply();
                                SharedPreferences prefs = getSharedPreferences("Prefs", MODE_PRIVATE);
                                boolean isLoggedIn = prefs.getBoolean("isLoggedIn", false);
                                Intent intent = new Intent(getApplicationContext(),Homepage.class);
                                intent.putExtra("isLoggedIn", isLoggedIn);
                                startActivity(intent);
                                finish();
                            }else{
                                Toast.makeText(Register.this, "Signup Failed!", Toast.LENGTH_SHORT).show();
                            }
                        }
                        else{
                            Toast.makeText(Register.this, "User already exists! Please login", Toast.LENGTH_SHORT).show();
                        }
                    }else{
                        Toast.makeText(Register.this, "Invalid Password!", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}